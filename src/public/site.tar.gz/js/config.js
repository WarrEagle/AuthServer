/**
 * Facebook Friends List Manager by Michael Quale and kickasschromeapps.com
 * Configurations.
 */
var Config = function() {
};

//localhost
//Config.appId = '';

//facebookfriendmanager.com
Config.appId = '114172142117022';